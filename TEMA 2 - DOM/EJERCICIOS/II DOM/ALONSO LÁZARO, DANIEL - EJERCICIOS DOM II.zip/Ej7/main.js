function cambiaEnlace(){
    var enlace = document.getElementById("enlace");
    enlace.href = "http://asyncore.ddns.net";
    enlace.textContent = "¡A asyncore.ddns.net!";
}