function resaltar(){
    var parrafo = document.getElementById("parrafo");
    parrafo.classList.toggle("resaltado");
}