function saludar(nombre) {
    return "Hola ".concat(nombre);
}
var mensaje = saludar('Mundo');
console.log(mensaje);
