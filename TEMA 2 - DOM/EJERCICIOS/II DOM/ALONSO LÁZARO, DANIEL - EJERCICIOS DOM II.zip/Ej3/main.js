function cambiarValue(){
    var input = document.getElementById("campo");
    input.value = "Nuevo valor";
}