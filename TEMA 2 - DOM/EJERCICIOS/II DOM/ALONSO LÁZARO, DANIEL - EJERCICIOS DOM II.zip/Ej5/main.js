function cambiarEstilos(){
    var parrafo = document.getElementById("parrafo");
    parrafo.style.fontSize = "30px";
    parrafo.style.backgroundColor = "lightblue";
}