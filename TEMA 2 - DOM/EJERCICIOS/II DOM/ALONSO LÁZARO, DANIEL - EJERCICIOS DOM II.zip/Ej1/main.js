function cambiarContenido(){
    var parrafo = document.getElementById("parrafo");
    parrafo.textContent = "¡El contenido ha sido cambiado!";
}