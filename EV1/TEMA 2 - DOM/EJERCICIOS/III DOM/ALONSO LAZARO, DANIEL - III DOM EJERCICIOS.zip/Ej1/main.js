function resaltar(){
    var parrafo = document.getElementById("parrafo");
    parrafo.classList.add("resaltado");
}